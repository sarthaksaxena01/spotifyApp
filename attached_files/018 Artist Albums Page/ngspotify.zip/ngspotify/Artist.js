"use strict";
var Artist = (function () {
    function Artist() {
    }
    return Artist;
}());
exports.Artist = Artist;
//# sourceMappingURL=Artist.js.map