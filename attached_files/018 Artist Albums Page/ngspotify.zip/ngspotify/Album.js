"use strict";
var Album = (function () {
    function Album() {
    }
    return Album;
}());
exports.Album = Album;
//# sourceMappingURL=Album.js.map